G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2026-08-16T17:40:41-06:00*
G04 #@! TF.ProjectId,Artificer A1 Board Rev 0.1,41727469-6669-4636-9572-20413120426f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2026-08-16 17:40:41*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
